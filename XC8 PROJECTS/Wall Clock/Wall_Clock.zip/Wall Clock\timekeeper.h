//This file contains pin definations and alias

#ifndef TIMEKEEPER_H_
#define TIMEKEEPER_H_

unsigned char Twenty_Four_Hrs = 0;
unsigned char secs = 00, mins = 00, hrs = 12, day = 1, month = 1, year = 15;
char sec_flag = 0, min_flag = 1, date_flag = 1;

void update_time();
void update_date();

#endif